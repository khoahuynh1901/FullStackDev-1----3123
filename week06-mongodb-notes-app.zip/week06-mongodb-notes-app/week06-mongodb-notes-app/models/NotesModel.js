const mongoose = require('mongoose');

// Define the Note schema
const NoteSchema = mongoose.Schema({
    noteTitle: {
        type: String,
        required: true,
        trim: true
    },
    noteDescription: {
        type: String,
        required: true,
        trim: true
    },
    priority: {
        type: String,
        enum: ['HIGH', 'MEDIUM', 'LOW'],  // Only these values are allowed
        required: true,
        default: 'MEDIUM'
    },
    dateAdded: {
        type: Date,
        default: Date.now  // Automatically set the current date when the note is created
    },
    dateUpdated: {
        type: Date,
        default: Date.now  // Automatically set the current date when the note is created
    }
}, {
    timestamps: true  // Automatically manage `createdAt` and `updatedAt` fields
});

// Create the Note model
const Note = mongoose.model('Note', NoteSchema);

module.exports = Note;
